package com.zybooks.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{



}
